package com.pidaus.pojeks;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void move(View view){
        TextView text1 = (TextView)findViewById(R.id.translatetext);
        Animation animation1 =
                AnimationUtils.loadAnimation(getApplicationContext(), R.anim.translate);
        text1.startAnimation(animation1);
    }

    public void up(View view){
        TextView text1 = (TextView)findViewById(R.id.translatetext);
        Animation animation1 =
                AnimationUtils.loadAnimation(getApplicationContext(), R.anim.up);
        text1.startAnimation(animation1);
    }

    public void down(View view){
        TextView text1 = (TextView)findViewById(R.id.translatetext);
        Animation animation1 =
                AnimationUtils.loadAnimation(getApplicationContext(), R.anim.down);
        text1.startAnimation(animation1);
    }

    public void left(View view){
        TextView text1 = (TextView)findViewById(R.id.translatetext);
        Animation animation1 =
                AnimationUtils.loadAnimation(getApplicationContext(), R.anim.left);
        text1.startAnimation(animation1);
    }
}
